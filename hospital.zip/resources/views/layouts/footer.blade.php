<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
   
    <!-- Default to the left -->
    @lang('Copyright') &copy; {{ date("Y") }} <a href="https://techwebdit.com" target="_blank">Techweb Bd It</a>. @lang('All rights reserved').
</footer>
