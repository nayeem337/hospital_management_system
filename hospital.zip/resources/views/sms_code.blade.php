<p>Hello,</p>
<p>Your verification code is: <strong>{{ $code }}</strong></p>
<p>Thank you!</p>
